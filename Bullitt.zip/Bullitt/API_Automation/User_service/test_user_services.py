import os

import requests
import json
import pytest
from _pytest import fixtures

from conftest import auth_key

path=os.getcwd()
print(path)
# create or update user details

os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)
    # input_file.close()

#pytest --fixtures ['C:\\Users\IM-LP-1764\\OneDrive\\Documents\\Bullitt API AWS\\Bullitt\\API_Automation\\lib']

# Create or update user details with empty IMSI
def test_create_or_update_user_details():
    url = data['userservice']['user_servicesAPI1']

    #url = ""
    payload = json.dumps({
        "userId": data['userservice']['userID'],
        "imsi": " ",
        "status": "22",
        "deviceType": "ANDROID"
    })
    #key="'{}'" .format(auth_key)
    #print(key)
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 200

# def test_create_or_update_user_details_response_validation():
#     url = data['userservice']['user_serviceAPI1']
#     payload = json.dumps({
#         "userId": data['userservice']['userID'],
#         "imsi": " ",
#         "status": "0",
#         "deviceType": "Android",
#         "deviceToken": " "
#     })
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': 'QxgpNqvOuT3AEqscRtCb8A',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 200
#   respanse_data = response.text
#    res = json.loads(respanse_data)
 #   assert res== data['userservice']['user_details_response']


# def test_create_or_update_user_details_empty_userid(auth_key):
#     url = data['userservice']['user_serviceAPI1']
#     payload = json.dumps({
#         "userId": '919515483896',
#         "imsi": "919515483896",
#         "status": "22",
#         "deviceType": "ANDROID",
#         "deviceToken": " "
#     })
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token'],
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 400

#Create or update user details with empty UserId
def test_create_or_update_user_details_empty_userid2():
    url = data['userservice']['user_servicesAPI2']
    #auth_key1 = auth_key()
    #url=""
    payload = json.dumps({
        "userId": '',
        "imsi": " ",
        "status": "22",
        "deviceType": "ANDROID",
        "deviceToken": " "
    })

    headers = {
        'accept': 'application/json',
        #'user-token': data['userservice']['user-token'],

        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400

def test_create_or_update_user_details_empty_userid3():
    url = data['userservice']['user_servicesAPI2']

    payload = json.dumps({
        "userId": ' ',
        "imsi": " ",
        "status": "22",
        "deviceType": "ANDROID",
        "deviceToken": " "
    })

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400


def test_create_or_update_user_details_empty_userid4():
    url = data['userservice']['user_servicesAPI2']
    payload = json.dumps({
        "userId": ' ',
        "imsi": " ",
        "status": "22",
        "deviceType": "ANDROID",
        "deviceToken": " "
    })

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400


# def test_create_or_update_user_details_invalid_userid():
#     url = data['userservice']['user_serviceAPI1']
#     payload = json.dumps({
#         "userId": data['userservice']['invalid_userid'],
#         "imsi": " ",
#         "status": "22",
#         "deviceType": "ANDROID",
#         "deviceToken": " "
#     })
#     headers = {
#         'accept': 'application/json',
#         'user-token': 'ImFtRfUITI_jhvor8o82Iw',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 404

#Create or update user details with invalid key
def test_create_or_update_user_details_invalid_key():
    url = data['userservice']['user_servicesAPI1']
    payload = json.dumps({
        "userId": data['userservice']['userID'],
        "imsi": " ",
        "status": "22",
        "deviceType": "ANDROID",
        "deviceToken": " "
    })

    headers = {
        'accept': 'application/json',
        'user-token': "T4mcrxY9jsdcbPODpZrMrt",
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 401

# verify user details with error 200 code validation
def test_userdetails_():
    #url=data['userservice']['user_servicesAPI1']+"/user/"+data['userservice']['userID']
    url = data['userservice']['user_servicesAPI1'] + "/user/" + data['userservice']['userID']
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
        }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 200

#verify user-details with empty response type
#  test_userdetails_with_empty_response_type_field():def
#     #url=data['userservice']['user_servicesAPI1']+"/user/"+data['userservice']['userID']
#     #url = data['userservice']['user_servicesAPI1'] + "/" + data['userservice']['userID']
#     url = data['userservice']['user_servicesAPI1']
#     print(url)
#
#     # url = data['userservice']['user_servicesAPI1'] + "" + data['userservice']['userID']
#     payload = json.dumps({
#         "userId": data['userservice']['userID'],
#         "imsi": " ",
#         "status": "22",
#         "deviceType": "ANDROID",
#         "deviceToken": " "
#     })
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token']
#         'Content-Type': 'application/json'
#     }
#
#     # url = "https://api.example.com/nonexistent_endpoint"
#     #
#     # response = requests.get(url)
#     #
#     # print("Status code:", response.status_code)
#
#     response = requests.get(url, headers=headers,data=payload)
#     print(response)
#     assert response.status_code == 404

#verify user-details with invalid auth-key
def test_userdetails_with_invalid_auth_key():
    # url=data['userservice']['user_serviceAPI1']+"/user/"+data['userservice']['userID']
    #url = data['userservice']['user_servicesAPI1'] + "/" + data['userservice']['userID']
    url="https://uat.bullittspace.com/api/userservice/user-details"
    #url = data['userservice']['user_servicesAPI1']

    print(url)
    payload = json.dumps({
        'userId': data['userservice']['userID'],
        'accept': 'application/json',
        'user-token':'T4mcrxY9jsdcbPODpZrM2',
        'Content-Type': 'application/json'
    })
    headers = {
        'accept': 'application/json',
        'user-token': '',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response)
    assert response.status_code == 401

#get sos_status
# def test_get__sos_status_closed():
#     # url=data['userservice']['user_serviceAPI1']+"/user/"+data['userservice']['userID']
#     #url = data['userservice']['user_serviceAPI1'] + "/sos-status" + "/user/"+data['userservice']['userID']
#     url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/sos-status/user/919515483896"
#     payload = ""
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token']
#         # 'Content-Type': 'application/json'
#     }
#     response = requests.get(url, headers=headers, data=payload)
#     assert response.status_code == 401
#     res=json.loads(response.text)
#     print(res)
#     assert res['data']['sosStatus']== None

# def test_get__sos_status__with_empty_response_type():
#     # url=data['userservice']['user_serviceAPI1']+"/user/"+data['userservice']['userID']
#     url = data['userservice']['user_serviceAPI1'] + " " + "/user/"+data['userservice']['userID']
#     #url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/ /user/919515483896"
#     payload = ""
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token']
#         # 'Content-Type': 'application/json'
#     }
#     response = requests.get(url, headers=headers, data=payload)
#     assert response.status_code == 404

#verify sos-status with invlid auth-key
# def test_get__sos_status__with_invlid_auth_key():
#     # url=data['userservice']['user_serviceAPI1']+"/user/"+data['userservice']['userID']
#     #url = data['userservice']['user_service2'] + "/sos-status" + "/user/"+data['userservice']['userID']
#     url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/sos-status/user/917893662962"
#
#     payload = ""
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': 'T4mcrxY9jsdcbPODpZrM2Q'
#         # 'Content-Type': 'application/json'
#     }
#     response = requests.get(url, headers=headers, data=payload)
#     assert response.status_code == 401

#verify block-users with 200 code
def test_get_block_user_with_valid_auth_key():
    url = data['userservice']['user_servicesAPI4']
    payload = json.dumps({
        'userId': "917893662962",
        'numberTobeBlocked': "919985212020",
        'blockLevel': "0",
        'comment': "test"
        })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_get_block_user_with_empty_responsetype():
    url = data['userservice']['user_servicesAPI2'] + " " + "/user/" + data['userservice']['userID']
    payload = ""
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 400


# def test_get_channel_or_userdetails_or_sos_status_block_user_userid_validtion():
#     url = data['userservice']['user_serviceAPI2'] + "/user/" + data['userservice']['userID']
#
#     payload = ""
#
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token']
#         # 'Content-Type': 'application/json'
#     }
#     response = requests.get(url, headers=headers, data=payload)
#     assert response.status_code == 200
#     respanse_data = response.text
#     res = json.loads(respanse_data)
#     assert res['data']['userId'] == data['userservice']['userID']

def test_get_channel_or_userdetails_or_sos_status_block_user_publishChannelId_validtion():
    url = "https://cloud-user-service-uat-etasd4b3tq-uc.a.run.app/api/userservice/channel-name/user/919515483896"

    payload = " "

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 400
    # respanse_data = response.text
    # res = json.loads(respanse_data)
    # assert res['data']['publishChannelId'] == 'bullitt.server.919515483896'


def test_get_config_value_based_on_config_name():
    url = data['userservice']['user_servicesAPI2']
    payload = json.dumps({
        "userId": data['userservice']['userID2']

    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'

    }

    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

#validating the response body base on config value
def test_get_config_value_based_on_config_name_Response_Validation():
    url = data['userservice']['user_servicesAPI2']
    payload = json.dumps({
        "userId": data['userservice']['userID'],
        "configName": "checkinMessage"
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'

    }

    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200
    response_data = response.text
    res = json.loads(response_data)
    print(res)

    assert res['data']['configValue']==" "


def test_get_config_value_based_on_config_name_empty_userid():
    url = data['userservice']['user_servicesAPI2']
    payload = json.dumps({
        "userId": '',

    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'

    }

    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400


def test_get_config_value_based_on_config_name_invalid_auth():
    url = data['userservice']['user_servicesAPI2']
    payload = json.dumps({
        "userId": "919515483896",
        "configName": ""
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'

    }

    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 401


def test_add_or_update_config_value():
    url = data['userservice']['user_servicesAPI4']
    payload = json.dumps({
        "mobileNumber": "919515483896",
        "configData": [
            {
                "configName": "checkinMessage",
                "configValue": "checking in"
            }
        ]
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
    }

    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 401

#validating config value base on config name
def test_add_or_update_config_value_validate_config_value():
    url = data['userservice']['user_servicesAPI3']
    payload = json.dumps({
        "mobileNumber": "917893662962",
        "configData": [
            {
                 "configName": "checkinMessage",
                 "configValue": "checking in"
            }
        ]
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
    }

    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 200
    respanse_data = response.text
    res = json.loads(respanse_data)
    assert res['data']['configDetails']['checkinMessage']=='checking in'

def test_add_or_update_config_value_invalid_key():
    url = data['userservice']['user_servicesAPI3']
    payload = json.dumps({
        "mobileNumber": "919515483896",
        "configData": [
            {
                "configName": "checkinMessage",
                "configValue": "satellite"
            }
        ]
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json'
    }

    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 401

def test_add_or_update_config_value_empty_configname():
        url = data['userservice']['user_servicesAPI3']
        payload = json.dumps({
            "mobileNumber": "919515483896",
            "configData": [
                {
                    "configName": " ",
                    "configValue": "checking in"
                }
            ]
        })
        headers = {
            'accept': 'application/json',
            'user-token': data['userservice']['user-token'],
            'Content-Type': 'application/json'
        }

        response = requests.put(url, headers=headers, data=payload)
        assert response.status_code == 401

def test_add_or_update_config_value_empty_configvalue():
        url = data['userservice']['user_servicesAPI3']
        payload = json.dumps({
            "mobileNumber": "917893662962",
            "configData": [
                {
                    "configName": "checkinMessage",
                    "configValue": " "
                }
            ]
        })
        headers = {
            'accept': 'application/json',
            'user-token': data['userservice']['user-token'],
            'Content-Type': 'application/json'
        }

        response = requests.put(url, headers=headers, data=payload)
        assert response.status_code == 200

def test_block_user():
   url=data['userservice']['user_servicesAPI4']
   payload=json.dumps({
        "userId": "917893662962",
        "numberTobeBlocked": "917386662736",
        "blockLevel": "2",
        "comment": "blocked"
  })
   headers = {
     'accept': 'application/json',
     'user-token': data['userservice']['user-token'],
     'Content-Type': 'application/json'
    }
   response=requests.put(url, headers=headers, data=payload)
   assert response.status_code==200
   respanse_data = response.text
   res = json.loads(respanse_data)
   print(res)
   # assert res['data'][1]['mobileNumber'] == '917386662736'


def test_block_user_satellite_block():
   url=data['userservice']['user_servicesAPI4']
   payload=json.dumps({
  "userId": data['userservice']['satellite_block'],
  "numberTobeBlocked": "917386662736",
  "blockLevel": "1",
  "comment": "blocked"
  })
   headers = {
     'accept': 'application/json',
     'user-token': data['userservice']['user-token'],
     'Content-Type': 'application/json'
    }
   response=requests.put(url, headers=headers, data=payload)
   assert response.status_code==401

def test_block_user_invalid_auth():
   url=data['userservice']['user_servicesAPI4']
   payload=json.dumps({
  "userId": "919515483896",
  "numberTobeBlocked": "917386662736",
  "blockLevel": "0",
  "comment": "blocked"
  })
   headers = {
     'accept': 'application/json',
     'user-token': data['userservice']['user-token'],
     'Content-Type': 'application/json'
    }
   response=requests.put(url, headers=headers, data=payload)
   assert response.status_code==401

def test_get_status_and_block_level_recipient_valid_data():
    url = data['userservice']['user_servicesAPI5']
    # url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/block-status-recipient"
    payload = json.dumps({
        "recipient": data['userservice']['blocked_recipient'],
        "sender": data['userservice']['blocked_sender']
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

#recipient has no blocked sender
def test_get_status_and_block_level_recipient_has_block_sender():
    url = data['userservice']['user_servicesAPI5']
    # url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/block-status-recipient"
    payload = json.dumps({
        "recipient": data['userservice']['blocked_recipient'],
        "sender": data['userservice']['blocked_sender']
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200
    res=json.loads(response.text)
    assert res['data']['blockLevel']== 0

def test_get_status_and_block_level_recipient_has_satellite_block_sender():
    url = data['userservice']['user_servicesAPI5']
    # url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/block-status-recipient"
    payload = json.dumps({
        "recipient": data['userservice']['satellite_block'],
        "sender": data['userservice']['blocked_sender']
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200
    res=json.loads(response.text)
    assert res['data']['blockLevel']== 0

#recipient has blocked sender
def test_get_status_and_block_level_recipient_has_no_blocked_sender():
    url = data['userservice']['user_servicesAPI5']
    # url="https://cloud-user-service-b3m2omfita-uc.a.run.app/api/userservice/block-status-recipient"
    payload = json.dumps({
        "recipient": data['userservice']['no_block_recepient'],
        "sender": data['userservice']['blocked_sender']
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200
    res=json.loads(response.text)
    assert res['data']['blockLevel']== 0

def test_get_status_and_block_level_recipient_empty_recipient_data():
    # url=data['userservice']['user_servicesAPI3']
    url = data['userservice']['user_servicesAPI5']
    payload = json.dumps({
        "recipient": " ",
        "sender": "917893662962"
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400
# This is a duplicate of above test case

# def test_get_status_and_block_level_recipient_empty_recipient_data2():
#     # url=data['userservice']['user_servicesAPI3']
#     url = data['userservice']['user_servicesAPI5']
#     payload = json.dumps({
#         "recipient": "918328189589",
#         "sender": "919985212017"
#     })
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token1'],
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 200
#

# This is a duplicate of above test case
# def test_get_status_and_block_level_recipient_empty_sender_data():
#     # url=data['userservice']['user_servicesAPI3']
#     url = data['userservice']['user_servicesAPI5']
#     payload = json.dumps({
#         "recipient": "",
#         "sender": "917893662962"
#     })
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token'],
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     print(response)
#     assert response.status_code == 400


def test_get_status_and_block_level_recipient_invalid_auth():
    # url=data['userservice']['user_servicesAPI3']
    url = data['userservice']['user_servicesAPI5']
    payload = json.dumps({
        "recipient": data['userservice']['recipient'],
        "sender": data['userservice']['sender']
    })
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token1'],
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 401


# def test_get_status_and_block_level_recipient_response_validation():
#     # url=data['userservice']['user_servicesAPI3']
#     url = data['userservice']['user_servicesAPI5']
#     payload = json.dumps({
#         "recipient": data['userservice']['recipient'],
#         "sender": data['userservice']['sender']
#     })
#     headers = {
#         'accept': 'application/json',
#         'user-token': data['userservice']['user-token1'],
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     respanse_data = response.text
#     res = json.loads(respanse_data)
#     assert res == data['userservice']['block_level']

def test_get_device_version_details():
    url=data['userservice']['user_servicesAPI6']
    payload=""
    headers={
        'accept': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_get_device_version_details2():
    url=data['userservice']['user_servicesAPI6']
    payload=""
    headers={
        'accept': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_get_device_version_details_response_validation():
    url=data['userservice']['user_servicesAPI6']
    payload=json.dumps({
            'device-type':'android'
    })
    headers={
        'accept': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 200
    respanse_data = response.text
    res = json.loads(respanse_data)
    print(res)
    assert res['mobile_app']['android']['force_update_version']==data['userservice']['mobile_app']['android']['force_update_version']