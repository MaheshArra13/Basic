import json
with open(r"C:\Users\apolagoni\Downloads\skylo DSI API\API_Automation\lib\config.json") as f:
    data=json.load(f)
