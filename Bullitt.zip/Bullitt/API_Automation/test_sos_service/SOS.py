# from distutils.command.config import config
import os
import pytest
import re
import requests
import json
import json

import pytest
from _pytest import fixtures

from conftest import auth_key

#from API_Automation.conftest import *

os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)



# import
# from conftest import *
# from lib.config import *
with open("config.json") as input_file:
    data = json.load(input_file)
    input_file.close()

# Test SOSOPEN with Mesgtype ContentOpenSOS
def testT1SOS_open_event_to_FPVALID ():
    #url = data['sosservices']['sosAPI1']
    #url = data['sosservices']['sosAPIDEV1']
    url = data['sosservices']['sosAPIUAT1']
    payload = json.dumps({
            "messageId": data['sosservices']['messageId'],
            "sender": data['sosservices']['sender1'],
            "type": "REGULAR",
            "latitude": 30,
            "longitude": 10,
            "altitude": 20,
            "gpsFix": "1",
            "messageType": "ContentOPENSos"

    })



    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    # assert response.status_code == 404 and response.text == 'Focus point url is not found'
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# Test SOSOPEN with Mesgtype ContentcloseSOS

def testT1SOS_open_event_to_FPVALID2():
        #url = data['sosservices']['sosAPI1']
        #url = data['sosservices']['sosAPIDEV1']
        url = data['sosservices']['sosAPIUAT1']
        payload = json.dumps({
            "messageId": data['sosservices']['messageId'],
            # "messageId": "919985212017",
            "sender": "911010101010",
            # "sender":"911010101010",
            "type": "REGULAR",
            "latitude": 30,
            "longitude": 10,
            "altitude": 20,
            "gpsFix": "1",
            "messageType": "ContentcloseSos"

        })

        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.post(url, headers=headers, data=payload)
        #assert response.status_code == 404
        assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# Test SOSOPEN with Mesgtype ContentcloseSOS and with invalid type
def testT1SOS_open2_event_to_FPVALID ():
    #url = data['sosservices']['sosAPI1']
    #url = data['sosservices']['sosAPIDEV1']
    url = data['sosservices']['sosAPIUAT1']
    payload = json.dumps({
            "messageId": data['sosservices']['messageId'],
           # "messageId": "919985212017",
           "sender": data['sosservices']['sender1'],

            "type": "c",
            "latitude": 30,
            "longitude": 10,
            "altitude": 20,
            "gpsFix": "1",
            "messageType": "ContentCLOSESos"

    })



    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    #assert response.status_code == 200
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# This is a duplicate of testT1SOS_open_event_to_FPVALID2
# def testT1SOS_CLOSE_event_to_FPVALID():
#    # url = data["sosservices"]["sosAPI1"]
#     url = data['sosservices']['sosAPIDEV1']
#     url = data['sosservices']['sosAPIUAT1']
#     payload = json.dumps({
#         "messageId": "918328189589",
#         "sender": data['sosservices']['sender1'],
#         "type": "REGULAR",
#         "latitude": data['sosservices']['messageId3'],
#         "longitude": data['sosservices']['messageId3'],
#         "altitude": data['sosservices']['messageId3'],
#         "gpsFix": data['sosservices']['messageId3'],
#         "messageType": "ContentCloseSos"
#
#     })
#     # key="'{}'" .format(auth_key)
#     # print(key)
#
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 200

# Test SOSOPEN with Mesgtype ContentcloseSOS and with invalid message type

def testT1SOS_close_event_to_FP2():
    #url = data["sosservices"]["sosAPI1"]
    #url = data['sosservices']['sosAPIDEV1']
    url = data['sosservices']['sosAPIUAT1']
    payload = json.dumps({
        "messageId": "918328189589",
        "sender": data['sosservices']['sender1'],
        "type": "REGULAR",
        "latitude": 30,
        "longitude": 10,
        "altitude": 20,
        "gpsFix": "0",
        "messageType": "ContentCloseSos"

    })
    headers = {
        'accept': 'application/json',

        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    #assert response.status_code == 200
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'


# Test SOSOPEN with Mesgtype ContentcloseSOS and with type zero

def testT1SOS_close_event_to_FP2number2():
    #url = data["sosservices"]["sosAPI1"]
    #url = data['sosservices']['sosAPIDEV1']
    url = data['sosservices']['sosAPIUAT1']

    payload = json.dumps({
        "messageId": "919985212017",
        "sender": data['sosservices']['sender1'],
        "type": "0",
        "latitude": 30,
        "longitude": 10,
        "altitude": 20,
        "gpsFix": "0",
        "messageType": "ContentCloseSos"

    })
    headers = {
        'accept': 'application/json',

        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    #assert response.status_code == 403
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# Test SOSClose with empty payload values

def testT1SOS_close_event_to_FP3_with_emptydata():
    #url = data["sosservices"]["sosAPI1"]
    #url = data['sosservices']['sosAPIDEV1']
    url = data['sosservices']['sosAPIUAT1']
    payload = json.dumps({
        "messageId": "",
        "sender": "",
        "type": "",
        "latitude": 0,
        "longitude": 0,
        "altitude": 0,
        "gpsFix": " ",
        "messageType": ""
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400

# Validate Send message to FP
def testSend_message_to_FP():
    #url = data['sosservices']['sosAPI2']
    #url = data['sosservices']['sosAPIDEV2']
    url =data['sosservices']['sosAPIUAT2']
    #url = "https://cloud-sos-microservice-b3m2omfita-uc.a.run.app/api/sosservice/text-message"
    payload=json.dumps({

            "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c",
            "sender": "917893662962",
            "type": "REGULAR",
            "latitude": 30,
            "longitude": 30,
            "message": "test",
            "messageType": "ContentTextMessageAndopenSOS"

         })
    # {
    #     "messageId": "918328189589",
    #     "sender": "919985212017",
    #     "type": "REGULAR",
    #     "latitude": 10,
    #     "longitude": 30,
    #     "altitude": 40,
    #     "gpsFix": "4d",
    #     "messageType": "ContentOpenSos"
    # }
    headers = {
              'accept': 'application/json',
              'Content-Type': 'application/json',
              'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'

        }
    response=requests.post(url, headers=headers, data=payload)
    #assert response.status_code == 200
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# Send message to FP with message type ContentTextMessageAndopenSOS
def testSend_message_to_FP2():
    url = data['sosservices']['sosAPIUAT4']

    payload=json.dumps(
            {
              "messageId": data["sosservices"]['messageId1'],
             # "sender":data["sosservices"]["sender1"],
              "sender": "911010101010",
              "type": "1",
              "latitude": 0,
              "longitude": 0,
              "message": "HI",
              "messageType": "ContentTextMessageAndopenSOS"

         })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
        }
    response=requests.post(url, headers=headers, data=payload)
    #assert response.status_code == 400
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# Send message to FP with invalid payload values

def testSend_message_to_FP2invalidempty():
    url = data['sosservices']['sosAPIUAT2']

    payload=json.dumps(
            {
              "messageId": data["sosservices"]['messageId1'],
              "sender": "91",
              "type": data["sosservices"]['messageId3'],
              "latitude": data["sosservices"]['messageId3'],
              "longitude": data["sosservices"]['messageId3'],
              "message": data["sosservices"]['messageId3'],
              "messageType": "ContentTextMessageAndopenSOS"

         })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
        }
    response=requests.post(url, headers=headers, data=payload)
    #assert response.status_code == 400
    assert '{"message":"Focus point url is not found.","statusCode":404,"error":true}'

# Send message - Recieve message from FP
def testSend_message_to_FP3():
    url = data['sosservices']['sosAPIUAT4']

    payload=json.dumps({

                "customerId": "901800010000857",
                "content": "test"

         })

    headers = {
             'accept': 'application/json',
             'Content-Type': 'application/json',
             'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'

    }
    response=requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

# Send message - Recieve message from FP with sender empty

def testSend_message_to_FP4empty():
    url = data['sosservices']['sosAPIUAT4']

    payload=json.dumps(
            {
              "messageId": data["sosservices"]['messageId'],
              "sender": " ",
              "type": "helo",
              "latitude": 10,
              "longitude": 20,
              "message": "HI",
              "messageType": ""

         })

    headers = {
             'accept': 'application/json',
             'Content-Type': 'application/json',
             'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'

    }
    response=requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400

# FP case closure using valid Customer Id
def testreceive_SOS_close_event_from_FP():
    #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/text-message"
    url = data['sosservices']['sosAPIUAT3']

    payload1=json.dumps(

        {
            "customerId": data['sosservices']['customerId1']
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'
    }
    response = requests.post(url, headers=headers, data=payload1)
    assert response.status_code == 200

# FP case closure using Invalid Customer Id
def  testreceive_SOS_close_event_from_FP2():
   # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/case-closure"
    url = data['sosservices']['sosAPIUAT3']

    payload2=json.dumps({

            "customerId": data['sosservices']['customerId3']
             })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'
        }
    response = requests.post(url, headers=headers, data=payload2)
    assert response.status_code == 200
# This case is a duplicate of testreceive_SOS_close_event_from_FP()
# def  testreceive_SOS_close_event_from_FP3():
#    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/case-closure"
#     url = data['sosservices']['sosAPIUAT3']
#
#     payload2=json.dumps({
#
#             "customerId": data['sosservices']['customerId1']
#              })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#         }
#     response = requests.post(url, headers=headers, data=payload2)
#     assert response.status_code == 404

# Close case by giving Customer Id empty
def  testreceive_SOS_close_event_from_FP4():
   # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/case-closure"
    url = data['sosservices']['sosAPIUAT3']

    payload=json.dumps({

            "customerId": ""
             })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'
        }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400

# This is a duplicate of testreceive_SOS_close_event_from_FP2()
# def  testreceive_SOS_close_event_from_FP5():
#    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/case-closure"
#     url = data['sosservices']['sosAPIUAT3']
#
#     payload2=json.dumps({
#
#             "customerId": "string"
#              })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#         }
#     response = requests.post(url, headers=headers, data=payload2)
#     assert response.status_code == 404
#
#

# Recieve SOS message from FP with empty Customer Id
def testreceive_SOS_message_from_FP_with_empty_customerId():
    url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    url = data['sosservices']['sosAPIUAT4']
    payload4 =json.dumps({
            "customerId": "",
            "content": "",
        })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'
    }
    response = requests.post(url,headers=headers,data=payload4)
    assert response.status_code == 400

# Recieve SOS message from FP with valid Customer Id
def testreceive_SOS_message_from_FP2valid():
    #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    url = data['sosservices']['sosAPIUAT4']
    payload = json.dumps({
            "customerId": data['sosservices']['IMSI1'],
             "content": "hu"
        })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

# This is a duplicate of testreceive_SOS_message_from_FP2valid()
# def testreceive_SOS_message_from_FP3valid():
#     #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
#     url = data['sosservices']['sosAPIUAT4']
#     payload4 = json.dumps({
#             "customerId": data['sosservices']['IMSI1'],
#              "content": "hello from sos"
#         })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json',
#         'x-api-key': 'AIzaSyCtnLJLt3wmgu55k2HhW8JELmMqv4ku7gc'
#     }
#     response = requests.post(url, headers=headers, data=payload4)
#     assert response.status_code == 200



def testreceive_SOS_message_event_from_FP4():
    url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    url = data['sosservices']['sosAPI5']
    payload4 = json.dumps({
        "customerId": "9110101010102354565868",
        "dlmsgId": "64a4cc49-3621-4698-80c8-f693a9ee06a8",
        "deliveryStatus": "ok"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 400

def testreceive_SOS_message_from_emptyFP2():
    #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    url = data['sosservices']['sosAPI4']
    payload4 = json.dumps({
            "customerId": "01010102354565868",
             "content": "sign"
        })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 404


def testreceive_SOS_message_frominvalidIMSI_FP2():
    #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    url = data['sosservices']['sosAPI4']
    payload4 = json.dumps({
            "customerId": "910000000009854946",
             "content": "hello"
        })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 404

def testreceive_SOS_message_from_FP5():
    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    url = data['sosservices']['sosAPI4']
    payload4 = json.dumps({
        "customerId": "911i84u5983459034580",
        "content": "hello"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 404
# Currently the delivery Status API is not in use

# def testsent_delivery_status_to_FP1():
#       #  url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
#         url = data['sosservices']['sosAPIUAT5']
#         payload4 = json.dumps({
#
#             "messageId": "0000000000002d642bd2782d0114",
#             "dataDeliveryStatus": 'false'
#
#         })
#         headers = {
#             'accept': 'application/json',
#             'Content-Type': 'application/json'
#         }
#         response = requests.post(url, headers=headers, data=payload4)
#         assert response.status_code == 200

#Currently the delivery Status API is not in use

# def testsent_delivery_status_to_FP2():
#         # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
#         url = data['sosservices']['sosAPI5']
#         payload4 = json.dumps({
#
#             "messageId": data['sosservices']['dlmsgId'],
#             "dataDeliveryStatus": 'true'
#
#         })
#         headers = {
#             'accept': 'application/json',
#             'Content-Type': 'application/json'
#         }
#         response = requests.post(url, headers=headers, data=payload4)
#         assert response.status_code == 200

# Currently the delivery Status API is not in use

# def testsent_delivery_status_to_FP3():
#     # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
#     url = data['sosservices']['sosAPI5']
#     payload4 = json.dumps({
#
#         "messageId": data['sosservices']['dlmsgId'],
#         "dataDeliveryStatus": 'true'
#
#     })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload4)
#     assert response.status_code == 200

# Currently the delivery Status API is not in use

    # def testsent_delivery_status_to_FP2():
    #     # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    #     url = data['sosservices']['sosAPI5']
    #     payload4 = json.dumps({
    #
    #         "messageId": "789878998",
    #         "dataDeliveryStatus": 'true'
    #
    #     })
    #     headers = {
    #         'accept': 'application/json',
    #         'Content-Type': 'application/json'
    #     }
    #     response = requests.post(url, headers=headers, data=payload4)
    #     assert response.status_code == 400

# Currently the delivery Status API is not in use

# def testsent_delivery_status_to_FP5():
#         # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
#         #url = data['sosservices']['sosAPI5']
#         url = data['sosservices']['sosAPIUAT5']
#         payload4 = json.dumps({
#
#             "messageId": " 90020030",
#             "dataDeliveryStatus": 'true'
#
#         })
#         headers = {
#             'accept': 'application/json',
#             'Content-Type': 'application/json'
#         }
#         response = requests.post(url, headers=headers, data=payload4)
#         assert response.status_code == 200
#
# Currently the delivery Status API is not in use

# def testsent_delivery_status_to_FP6():
#     # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
#     #url = data['sosservices']['sosAPIDEV5']
#     url = data['sosservices']['sosAPIUAT5']
#     payload4 = json.dumps({
#
#         "messageId": data['sosservices']['dlmsgId1'],
#         "dataDeliveryStatus": 'true'
#
#     })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload4)
#     assert response.status_code == 200
#





