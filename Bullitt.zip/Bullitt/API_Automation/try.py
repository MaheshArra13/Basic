string1="500 12"
l1=[]
a=string1.replace(" ",",")
print(a)
