from distutils.command.config import config
import os
import pytest
import re
import requests
import json
import json




from conftest import *
# from lib.config import *
#from API_Automation.conftest import *
path=os.getcwd()
print(path)
os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)
    # input_file.close()


def testTo_publish_a_regular_message1 ():
    #url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API1']
    payload = json.dumps({
            #"messageId": data['sosservices']['messageId'],

           #"sender": data['sosservices']['sender1'],
            "type": "string",
             "message": "Hello",
             "payload": "Hello",
             "messageType": "contentTextMessage",
             "recipient": "9199999999",
             "sender": "9111111111",
             "messageId": "DE34FFSE65",
             "latitude": "35.7805° N",
             "longitude": "116.4173° W",
            "altitude": "150",
            "channelName": "bullitt.9199999999"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_messaging_service2 ():
    #url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API2']
    payload = json.dumps({
            #"messageId": data['sosservices']['messageId'],

           #"sender": data['sosservices']['sender1'],
        "type": "string",
        "message": "Hello",
        "payload": "Hello",
        "messageType": "contentTextMessage",
        "recipient": "9199999999",
        "sender": "9111111111",
        "messageId": "DE34FFSE65",
        "latitude": "35.7805° N",
        "longitude": "116.4173° W",
        "altitude": "150",
        "channelName": "bullitt.9199999999"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200


def test_messaging_service3():
    #url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API3']
    #url = 'https://cloud-messaging-service-qa-b3m2omfita-uc.a.run.app/api/v1/delivery-message'
    payload = json.dumps({
            #"messageId": data['sosservices']['messageId'],

           #"sender": data['sosservices']['sender1'],
        "type": "string",
        "message": "Hello",
        "payload": "Hello",
        "messageType": "contentTextMessage",
        "recipient": "9199999999",
        "sender": "9111111111",
        "messageId": "DE34FFSE65",
        "channelName": "bullitt.9199999999",
        "reasonCode": 1,
        "latitude": "35.7805° N",
        "longitude": "116.4173° W",
        "altitude": "150"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200




def test_sms_messaging():
    # url=data['userservice']['user_serviceAPI1']+"/user/"+data['userservice']['userID']
    url = data['sosservices']['messaging_service_API4']
    payload = ""

    headers = {
        'accept': 'application/json',
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_sms_messaging5():
    # url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API3']
    payload = json.dumps({
        # "messageId": data['sosservices']['messageId'],

        # "sender": data['sosservices']['sender1'],
         "type": "string",
         "message": "Hello",
         "payload": "Hello",
         "messageType": "contentTextMessage",
         "deviceType": "Android",
         "deviceToken": "f34rg45h45h56ht5hh",
         "recipient": "9199999999",
         "sender": "9111111111",
         "messageId": "DE34FFSE65",
         "channelName": "bullitt.9199999999",
         "reasonCode": 1,
         "latitude": "35.7805° N",
         "longitude": "116.4173° W",
         "altitude": "150"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_sms_messaging6():
    # url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API6']
    payload = json.dumps({
        # "messageId": data['sosservices']['messageId'],

        # "sender": data['sosservices']['sender1'],
        "deviceType": "Android",
        "deviceToken": "f34rg45h45h56ht5hh",
        "channelName": "bullitt.9199999999"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_sms_messaging7():
    # url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API7']
    payload = json.dumps({
        # "messageId": data['sosservices']['messageId'],

        # "sender": data['sosservices']['sender1'],
        "deviceType": "Android",
        "deviceToken": "f34rg45h45h56ht5hh",
        "channelName": "bullitt.9199999999"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200


# def Test_to_get_message_delivery_status():
#     url = data['sosservices']['messaging_service_API2']
#     payload = json.dumps({
#
#         "type": "string",
#         "message": "Hello",
#         "payload": "Hello",
#         "messageType": "contentTextMessage",
#         "recipient": "9199999999",
#         "sender": "9111111111",
#         "messageId": "DE34FFSE65",
#         "latitude": "35.7805° N",
#         "longitude": "116.4173° W",
#         "altitude": "150",
#         "channelName": "bullitt.9199999999"
#         })
#
#           headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 200
def testTo_publish_a_regular_message1_2 ():
    #url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API1']
    payload = json.dumps({
            #"messageId": data['sosservices']['messageId'],

           #"sender": data['sosservices']['sender1'],
            "type": "string",
             "message": "Hello",
             "payload": "Hello",
             "messageType": "contentTextMessage",
             "recipient": "9199999999",
             "sender": "9111111111",
             "messageId": "DE34FFSE65",
             "latitude": "35.7805° N",
             "longitude": "116.4173° W",
            "altitude": "150",
            "channelName": "bullitt.9199999999"

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_messaging_service2_2 ():
    #url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API2']
    payload = json.dumps({
            #"messageId": data['sosservices']['messageId'],

           #"sender": data['sosservices']['sender1'],
        "type": "string",
        "message": "Hello",
        "payload": "Hello",
        "messageType": data['sosservices']['messageIdE'],
        "recipient": data['sosservices']['messageIdE'],
        "sender": data['sosservices']['messageIdE'],
        "messageId": data['sosservices']['messageIdE'],
        "latitude": data['sosservices']['messageIdE'],
        "longitude": data['sosservices']['messageIdE'],
        "altitude": data['sosservices']['messageIdE'],
        "channelName":data['sosservices']['messageIdE']

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400


def test_messaging_service3_2():
    #url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API3']
    payload = json.dumps({
            #"messageId": data['sosservices']['messageId'],

           #"sender": data['sosservices']['sender1'],
        "type": "string",
        "message": "Hello",
        "payload": "Hello",
        "messageType": data['sosservices']['messageIdE'],
        "recipient": data['sosservices']['messageIdE'],
        "sender": data['sosservices']['messageIdE'],
        "messageId": data['sosservices']['messageIdE'],
        "channelName": data['sosservices']['messageIdE'],
        "reasonCode": 1,
        "latitude": data['sosservices']['messageIdE'],
        "longitude": data['sosservices']['messageIdE'],
        "altitude": data['sosservices']['messageIdE']

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400




def test_sms_messaging_get4_2():
    # url=data['userservice']['user_serviceAPI1']+"/user/"+data['userservice']['userID']
    url = data['sosservices']['messaging_service_API4']
    payload = " "

    headers = {
        'accept': 'application/json',
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 400

# def test_sms_messaging5_2():
#     # url = data['sosservices']['sosAPI1']
#     url = data['sosservices']['messaging_service_API3']
#     payload = json.dumps({
#         # "messageId": data['sosservices']['messageId'],
#
#         # "sender": data['sosservices']['sender1'],
#          "type": "string",
#          "message": "Hello",
#          "payload": "Hello",
#          "messageType": "contentTextMessage",
#          "deviceType": "Android",
#          "deviceToken": "f34rg45h45h56ht5hh""f34rg45h45h56ht5hh",
#          "recipient": "9199999999",
#          "sender": "9111111111",
#          "messageId": "DE34FFSE65",
#          "channelName": "bullitt.9199999999",
#          "reasonCode": 1,
#          "latitude": "35.7805° N",
#          "longitude": "116.4173° W",
#          "altitude": "150"
#
#     })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 400

# def test_sms_messaging5_3invalid_url():
#     # url = data['sosservices']['sosAPI1']
#     url = data['sosservices']['messaging_service_API3']
#     payload = json.dumps({
#         # "messageId": data['sosservices']['messageId'],
#
#         # "sender": data['sosservices']['sender1'],
#          "type": "string",
#          "message": "Hello",
#          "payload": "Hello",
#          "messageType":data['sosservices']['messageIdE'],
#          "deviceType": data['sosservices']['messageIdE'],
#          "deviceToken": data['sosservices']['messageIdE'],
#          "recipient": "9199999999",
#          "sender": "9111111111",
#          "messageId": "DE34FFSE65",
#          "channelName": data['sosservices']['messageIdE'],
#          "reasonCode": 1,
#          "latitude": data['sosservices']['messageIdE'],
#          "longitude": data['sosservices']['messageIdE'],
#          "altitude": "150"
#
#     })
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 400

def test_sms_messaging6_2():
    # url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API6']
    payload = json.dumps({
        # "messageId": data['sosservices']['messageId'],

        # "sender": data['sosservices']['sender1'],
        "deviceType": data['sosservices']['messageIdE'],
        "deviceToken": data['sosservices']['messageIdE'],
        "channelName": data['sosservices']['messageIdE']

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400



def test_sms_messaging7_2():
    # url = data['sosservices']['sosAPI1']
    url = data['sosservices']['messaging_service_API7']
    payload = json.dumps({
        # "messageId": data['sosservices']['messageId'],

        # "sender": data['sosservices']['sender1'],
        "deviceType": data['sosservices']['messageIdE'],
        "deviceToken": data['sosservices']['messageIdE'],
        "channelName": data['sosservices']['messageIdE']

    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400