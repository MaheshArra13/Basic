from distutils.command.config import config

import pytest
import re
import requests
import json
import os
import json



#import
# from conftest import *
# from lib.config import *
with open("config.json") as input_file:
    data = json.load(input_file)
    input_file.close()

def test_sms_service_valid():
    url = data['sosservices']['sms_service_API']
    payload1 = json.dumps({

    "messageId": "0000000bdea02d6332701d2d0078",
    "payload": "Testing the UAT string service",
    "sender": "+918639472920",
    "recipient": "+919666662699"

    })
    headers = {
    'x-api-key': 'AIzaSyDSZgG-zbGJDRDUWaND5PM5EgYaP8uqxLE' ,
    'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload1)
    assert response.status_code == 200

def test_sms_service_valid2():
    url = data['sosservices']['sms_service_API']
    payload1 = json.dumps({

    "messageId": " ",
    "payload": "Testing the UAT string service",
    "sender": " ",
    "recipient": " "

    })



    headers = {
    'x-api-key': 'AIzaSyDSZgG-zbGJDRDUWaND5PM5EgYaP8uqxLE' ,
    'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload1)
    assert response.status_code == 400



