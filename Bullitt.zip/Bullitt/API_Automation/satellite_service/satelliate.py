import os
import requests
import json
import pytest

from _pytest import fixtures

from conftest import auth_key

#from API_Automation.conftest import *
path=os.getcwd()
print(path)
os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)
    # input_file.close()



def test_non_ip_data_from_core_network():
    url=data['satellite_service']['satellite_service_API1']
    payload=json.dumps({

        "appId": "bullitt.msg.uat",
        "ueExternalIdentifier": "901800010000074@dmp.skylo.tech",
        "contentData": {
        "smpContent": {
        "content": "wertyhj",
        "control": {
        "receipt": 0
      },
       "userId": "917893662962"
    },
       "smpHeader": {
       "version": 0,
       "ackFlag": 0,
       "msgCounter": 0,
       "contentType": 20,
       "timestamp": 0
    }
  }
    })
    headers={
        'accept': 'application/json' ,
        'Content-Type': 'application/json',
        'x-api-key' : 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response=requests.post(url, headers=headers, data=payload)
    assert response.status_code ==200

# def test_non_ip_data_from_core_network2():
#     url=data['satellite_service']['satellite_service_Api1']
#     payload=json.dumps({
#             "appId": data['satellite_service']['appIdQA'],
#             "ueExternalIdentifier": "901800010000012dmp.skylo.tech",
#              "contentData": {
#              "smpContent": {
#             "content": "wertyhj",
#             "control": {
#             "receipt": 0
#       },
#             "userId": "918885533114"
#     },
#              "smpHeader": {
#             "version": 0,
#            "ackFlag": 0,
#            "msgCounter": 0,
#            "contentType": 20,
#            "timestamp": 0
#     }
#   }
#     })
#     headers={
#         'accept': 'application/json' ,
#         'Content-Type': 'application/json'
#     }
#     response=requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 200
#
# def test_non_ip_data_from_core_network_empty_ueExternalIdentifier():
#     url=data['satellite_service']['satellite_service_Api1']
#     payload=json.dumps({
#
#     "appId": data['satellite_service']['appIdQA'],
#
#     "ueExternalIdentifier": " ",
#
#     "contentData": {
#
#         "smpContent": {
#
#             "deliveryTimestamp": 1670473778,
#
#             "messageId": " "
#
#         },
#
#         "smpHeader": {
#
#             "ackFlag": 0,
#
#             "contentType": 17,
#
#             "msgCounter": 1,
#
#             "timestamp": 1663325387,
#
#             "version": 1
#
#         }
#
#     },
#
#     "dataSizeInbytes": 26
#
#     })
#     headers={
#         'accept': 'application/json' ,
#         'Content-Type': 'application/json'
#     }
#     response=requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 200
#
# def test_non_ip_data_from_core_network_empty_ueExternalIdentifier2():
#         url = data['satellite_service']['satellite_service_Api1']
#         payload = json.dumps({
#
#             "appId":  data['satellite_service']['appIdQA'],
#
#             "ueExternalIdentifier": " ",
#
#             "contentData": {
#
#                 "smpContent": {
#
#                     "deliveryTimestamp": 1670473778,
#
#                     "messageId": " "
#
#                 },
#
#                 "smpHeader": {
#
#                     "ackFlag": 0,
#
#                     "contentType": 17,
#
#                     "msgCounter": 1,
#
#                     "timestamp": 1663325387,
#
#                     "version": 1
#
#                 }
#
#             },
#
#             "dataSizeInbytes": 26
#
#         })
#         headers = {
#             'accept': 'application/json',
#             'Content-Type': 'application/json'
#         }
#         response = requests.post(url, headers=headers, data=payload)
#         assert response.status_code == 200
#
# Recipient Id should be mapped with IMSI for dl
def test_send_satellite_msg_dl():
    url = data['satellite_service']['satellite-service_API2']
    payload = json.dumps(
        {

  "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c",
  "sender": "916302505189",
  "recipient": "917893662962",
  "payload": "Hi Hello",
  "ackFlag": 1,
  "contentType": 16,
  "version": 1,
  "msgCounter": 10,
  "receipt": 2,
  "latitude": 9.243243243,
  "longitude": 9.023432432,
  "gpsFix": "0"
})
    headers={
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response =   requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400

def test_send_satellite_msg_response_validation():
    url = data['satellite_service']['satellite-service_API2']
    payload=json.dumps({
        "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c",
        "sender": '916302505189',
        "recipient": "917893662962",
        "payload": "Hi Hello",
        "ackFlag": 1,
        "contentType": 20,
        "version": 1,
        "msgCounter": 10,
        "receipt": 2,
        "latitude": 9.243243243,
        "longitude": 9.023432432,
        "gpsFix": "0"
    })
    headers={
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response=requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400
    # respanse_data = response.text
    # res = json.loads(respanse_data)
    # assert res==data['satellite_service']['send_satellite_message_status']



def test_send_satellite_msg_empty_sender():
    url = data['satellite_service']['satellite-service_API2']
    payload = json.dumps({
  "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c",
  "sender": " ",
  "recipient": "917893662962",
  "payload": "Hi Hello",
  "ackFlag": 1,
  "contentType": 16,
  "version": 1,
  "msgCounter": 10,
  "receipt": 2,
  "latitude": 9.243243243,
  "longitude": 9.023432432,
  "gpsFix": "0"
    })
    headers = {
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400


def test_send_satellite_msg_empty_receiver():
    url = data['satellite_service']['satellite-service_API2']
    payload = json.dumps({
        "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c",
        "sender": '916302505189',
        "recipient": " ",
        "payload": "Hi Hellojhgfdfghjkjhgfdxcrfvt",
        "ackFlag": 1,
        "contentType": 16,
        "version": 1,
        "msgCounter": 10,
        "receipt": 2

    })
    headers = {
        'accept': 'application/json',
        'APP-ID': data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400


# def test_send_satellite_msg_invalid_IMSI():
#     url = data['satellite_service']['satellite-service_Api2']
#     payload = json.dumps({
#         "messageId": "string",
#         "sender": data['satellite_service']['invalid_ImsI_mobilenumber'],
#         "recipient": data['satellite_service']['recipient'],
#         "payload": "Hi Hellojhgfdfghjkjhgfdxcrfvt",
#         "ackFlag": 1,
#         "contentType": 16,
#         "version": 1,
#         "msgCounter": 10,
#         "receipt": 2
#
#     })
#     headers = {
#         'accept': 'application/json',
#         'APP-ID': 'bullitt.msg.qa',
#         'Content-Type': 'application/json'
#     }
#     response = requests.post(url, headers=headers, data=payload)
#     assert response.status_code == 404


def  test_fetch_UE_Network_status():
    url=data['satellite_service']['satellite_service_API3']

    payload=json.dumps({
    "ueExternalIdentifier": data['satellite_service']['ueExternalIdentifier']

    })

    headers={
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200
    # respanse_data = response.text
    # res = json.loads(respanse_data)
    # assert res['networkStatus']=='ATTACHED'

def test_fetch_UE_Network_status_response_validtion():
    url=data['satellite_service']['satellite_service_API3']

    payload=json.dumps({
    "ueExternalIdentifier": data['satellite_service']['ueExternalIdentifier']

    })

    headers={
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_fetch_UE_Network_status_response_validation():
    url=data['satellite_service']['satellite_service_API3']

    payload=json.dumps({
    "ueExternalIdentifier": "90199999113@dmp.skylo.tech"

    })

    headers={
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400
    # res=json.loads(response.text)
    # assert res['networkStatus'] == 'ATTACHED'

# The status code should not be 200
def test_fetch_UE_Network_status_invalid_appid():
    url=data['satellite_service']['satellite_service_API3']

    payload=json.dumps({
        "ueExternalIdentifier": data['satellite_service']['ueExternalIdentifier']

    })

    headers={
        'accept': 'application/json',
        'APP-ID':  'Bullitt.mesg.uatt',
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200


def test_fetch_UE_Network_status_empty_ueExternalIdentifier():
    url=data['satellite_service']['satellite_service_API3']

    payload=json.dumps({
    "ueExternalIdentifier": " "

    })

    headers={
        'accept': 'application/json',
        'APP-ID':  data['satellite_service']['appIduat'],
        'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 404

# Need to check
def test_subscribe_for_UE_notifications():
     url=data['satellite_service']['satellite_service_API4']
     payload=json.dumps({

             "ueExternalIdentifierList": [
                 "901800010001030@dmp.skylo.tech"
             ]

                           })

     headers={
         'accept': 'application/json',
         'APP-ID': data['satellite_service']['appIduat'],
         'Content-Type': 'application/json',
         'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
     }

     response=requests.post(url, headers=headers, data=payload)
     assert response.status_code == 200

def test_subscribe_for_UE_notifications_with_empty_UEIdentifier():
     url = data['satellite_service']['satellite_service_API4']
     payload = json.dumps({
         "ueExternalIdentifierList": [

         ]
     })

     headers = {
         'accept': 'application/json',
         'APP-ID': data['satellite_service']['appIduat'],
         'Content-Type': 'application/json',
         'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
     }

     response = requests.post(url, headers=headers, data=payload)
     assert response.status_code == 400

     # result=json.loads(response.text)
     # print(result)
     # assert result == data['satellite_service']['UE_subscribe_notifications']

# Below case returning status code=200 even if a invalid "ueExternalIdentifierList" is given. This is in both Postman and Swagger.

def test_subscribe_for_UE_notifications_Invalid_App_Id():
    url = data['satellite_service']['satellite_service_API4']
    payload = json.dumps({
        "ueExternalIdentifierList": [
            "901800010001030@dmp.skylo.tech"
        ]
    })

    headers = {
         'accept': 'application/json',
         #'APP-ID': data['satellite_service']['appIdQA'],
         'APP-ID':'bulli.mesg.qa',
         'Content-Type': 'application/json',
         'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'
    }

    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 401

def test_cancel_existing_downlink_data_transaction():
    url=data['satellite_service']['satellite_service_API5']
    payload=json.dumps({
         "ueExternalIdentifier": data['satellite_service']['ueExternalIdentifier'] ,
         "dlMessageIds": [
                     1671973592
                     ]
                       })
    headers= {
         'accept': 'application/json',
         'APP-ID': data['satellite_service']['appIduat'],
         'Content-Type': 'application/json',
        'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

def test_cancel_existing_downlink_data_transaction_invalid_id():
    url=data['satellite_service']['satellite_service_API5']
    payload=json.dumps({
    "ueExternalIdentifier": "901800010001030@dmp.skylo.tech",
    "dlMessageIds": [
        "00000573554b2d632454cb2d0001"
    ]
    })
    headers= {
         'accept': 'application/json',
         'APP-ID': data['satellite_service']['appIduat'],
         'Content-Type': 'application/json',
         'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 401

def test_data_delivery_notification_status():
    url=data['satellite_service']['satellite_service_API6']
    payload=json.dumps({
                 "event": "DL_DATA_DELIVERY_STATUS_NOTIFICATION",
                 "dlMessageId": "0",
                 "ueExternalIdentifier": "901800010001030@dmp.skylo.tech",
                 "deliveryStatus": "SUCCESS"
            })
    headers={
         'accept': 'application/json',
         'APP-ID': data['satellite_service']['appIduat'],
         'Content-Type': 'application/json',
         'x-api-key': 'nBlVpexoB96fG9Y9F86pv1zDj4a662Sc2layE9Ge'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200












