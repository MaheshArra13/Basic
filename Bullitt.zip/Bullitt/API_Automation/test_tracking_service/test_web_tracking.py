#from distutils.command.config import config
import os
import requests
import json
import pytest
from _pytest import fixtures

from conftest import auth_key

#from API_Automation.conftest import *
path=os.getcwd()
print(path)
os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)
    # input_file.close()

def test_tracking_add_or_update_tracking_value():
    url = data['userservice']["tracking_service_API1"]
    payload = json.dumps(
        {
            "sender": "918328189589",
            #"messageType": "CONTENTLOCATION",
            "messageType": "starttracking",
            "duration": "30",
            "frequency": "20",
            "latitude": "17.345",
            "longitude": "17.54",
            "messageId": "00D62299495B2D63Eceeae2D00001"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_tracking_add_or_update_tracking_value2():
    url = data['userservice']["tracking_service_API1"]
    payload = json.dumps(
        {
                "sender": "91998521217",
                "messageType": "918328189589",
                "duration": "23",
                "frequency": "32",
                "latitude": "12",
                "longitude": "12",
                "messageId": "21"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_tracking_add_or_update_tracking_value3():
    url = data['userservice']["tracking_service_API1"]
    payload = json.dumps(
        {
                "sender": "000",
                "messageType": "222222221",
                "duration": "2222222xxxxx",
                "frequency": "cxcxcx",
                "latitude": "cxcx",
                "longitude": "xez3",
                "messageId": "x23"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_tracking_add_or_update_tracking_value4():
    url = data['userservice']["tracking_service_API1"]
    payload = json.dumps(
        {
                "sender": " ",
                "messageType": "",
                "duration": "",
                "frequency": "",
                "latitude": "",
                "longitude": "",
                "messageId": ""
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_tracking_open_tracking_event1():
    url = data['userservice']["tracking_service_API4"]

    payload = json.dumps(
        {
            "sender": "917893662962",
            "contentOtherType": "STARTTRACKING",
            "duration": "10",
            "frequency": "3",
            "latitude": "30",
            "longitude": "10",
            "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c"
        }

    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

#Open tracking even with empty payload
def test_tracking_open_tracking_event2():
    url = data['userservice']["tracking_service_API4"]
    print(url)
    payload = json.dumps(
        {
            "sender": "",
            "messageType": "",
            "duration": "",
            "frequency": "",
            "latitude": "",
            "longitude": "",
            "messageId": ""
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 400

#This case is a duplicate of the above test case
# def test_tracking_open_tracking_event3():
#     url = data['userservice']["tracking_service_API4"]
#
#     payload = json.dumps(
#         {
#             "sender": " ",
#             "messageType": "",
#             "duration": "",
#             "frequency": "",
#             "latitude": "",
#             "longitude": "",
#             "messageId": ""
#         }
#     )
#
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.put(url, headers=headers, data=payload)
#     assert response.status_code == 404

# Open tracking even with invalid payload content
def test_tracking_open_tracking_event4():
    url = data['userservice']["tracking_service_API4"]
    payload = json.dumps(
        {
            "sender": "dfsdfdsaf",
            "contentOtherType": "sdfsadfsadf",
            "duration": "sdasd",
            "frequency": "xcv",
            "latitude": "zdf",
            "longitude": "sdfs",
            "messageId": "sdfsadf"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }

   # response = requests.put(url, headers=headers, data=payload)
    response = requests.post(url, headers=headers, data=payload)

   # assert response.status_code == 404
    assert response.status_code == 400


def test_tracking_close_tracking_event1():
    url = data['userservice']["tracking_service_API5"]

    payload = json.dumps(
        {
            "sender": "919985212017",
            "messageType": "closetracking",
            "duration": "12",
            "frequency": "22",
            "latitude": "12",
            "longitude": "21",
            "messageId": "211111922d0290300001"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 200



#Close tracking event by giving invalid payload content
def test_tracking_close_tracking_event2():
    url = data['userservice']["tracking_service_API5"]

    payload = json.dumps(
        {
            "sender": "e323ee32ee23e",
            "contentOtherType": "asfsadfdsaf",
            "latitude": "30",
            "longitude": "393",
            "messageId": "sdfsafddsafsadf"
        }

    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 400

# The current test case is a duplicate of the above case
# def test_tracking_close_tracking_event3():
#     url = data['userservice']["tracking_service_API3"]
#
#     payload = json.dumps(
#         {
#             "sender": " 23456765432",
#             "messageType": "close tracking ",
#             "duration": "423333334",
#             "frequency": "42344",
#             "latitude": "52352",
#             "longitude": "5",
#             "messageId": "v532vc253v"
#         }
#     )
#
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json',
#         'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
#     }
#     response = requests.put(url, headers=headers, data=payload)
#     #assert response.status_code == 404
#     assert response.status_code == 400


def test_tracking_close_tracking_event4():
    url = data['userservice']["tracking_service_API3"]

    payload = json.dumps(
        {
            "sender": " ",
            "messageType": "",
            "duration": "",
            "frequency": "",
            "latitude": "",
            "longitude": "",
            "messageId": ""
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url, headers=headers, data=payload)
    #assert response.status_code == 404
    assert response.status_code == 400


# def test_fcm_tracking_token1():
#     url = data['userservice']["tracking_service_API6"]
#
#     payload = json.dumps(
#         {"type": "SUBSCRIBE",
#          "fcmToken": "ft4nT0r5hGCws1d5oQ3DXN:APA91bHzIAcV6B0cJU9yNlTSCTiRMKb7Y5lPnowHn4maAc_qRRL_mzmoI8ZXgEzykhXmOqd_vslng0I4uAOdcVgzh0KAS65FoYzcvmAgfwoDws0KikZl2NDbDLSDwCASn9btVRMmObQx",
#          "trackingId": "86NM18QF",
#          "session":"PRIVATE"
#
#          }
#     )
#
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json',
#         'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
#
#     }
#     #response = requests.put(url, headers=headers, data=payload)
#     response = requests.post(url, headers=headers, data=payload)
#
#     assert response.status_code == 404

# get client fcm tracking token with valid fcm token
def test_fcm_tracking_token1():
    url = data['userservice']["tracking_service_API6"]

    payload = json.dumps(
        {

  "trackingId": "25AI25FS",
  "fcmToken": "dQtGqagtRyGC_u81UMhaGp:APA91bH6mrD4rcDSqiV2Q2l-kn1goIPC9IEsoMc5hcSb672eVhVtpyxaB1oy0an7it9h8BWKivUtJb-Opj_lXLwRE3iJAQ2bhFAZfXL2FIlCePM-c3Y_8SsYre5311g4dbo3V2UoxEM2",
  "type": "PRIVATE",
  "session": "wwwwww"
}

    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 200

# fcm tracking token invalid payload content throwing internal 500 error with invalid tracking Id
def test_fcm_tracking_token2():
    url = data['userservice']["tracking_service_API6"]

    payload = json.dumps(
        {

            "trackingId": "5345235",
            "fcmToken": "dQtGqagtRy1UMhaGp:APA91bH6mrD4rcDSqiV2Q2l-kn1goIPC9IEsoMc5hcSb672eVhVtpyxaB1oy0an7it9h8BWKivUtJb-Opj_lXLwRE3iJAQ2bhFAZfXL2FIlCePM-c3Y_8SsYre5311g4dbo3V2UoxEM2",
            "type": "sdfdsf",
            "session": "asdasd"
         }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk88'
        #z-api-key is not there

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 404

# fcm tracking token empty payload content throwing internal 500 error with invalid tracking Id
def test_fcm_tracking_token3():
    url = data['userservice']["tracking_service_API6"]

    payload = json.dumps(
        {"type": " ",
         "fcmToken": " ",
         "trackingId": " ",
         "session": " "
         }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk88'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 404

# get client fcm tracking token with invalid fcm token
def test_fcm_tracking_token4():
    url = data['userservice']["tracking_service_API6"]

    payload = json.dumps(
        {"type": "SUBSCRIBE",
         "fcmToken": "ft4nT0r5hGCws1d5oQ3DXN:APA91bHzIAcV6B0cJU9yNlTSCTiRMKb7Y5lPnowHn4maAc_qRRL_mzmoI8ZXgEzykhXmOqd_vslng0I4uAOdcVgzh0KAS65FoYzcvmAgfwoDws0KikZl2NDbDLSDwCASn9btVRMmObQx",
         "trackingId": "86NM18QF"
         }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk88'
    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 404

# This test case is duplicate of the invalid fcm token
def test_fcm_tracking_token5():
    url = data['userservice']["tracking_service_API6"]

    payload = json.dumps(
        {
        "type": "SUBSCRIBE",
         "fcmToken": "ft4moI8ZXgEzykhXmOqbtVRMmObQx",
         "trackingId": "86NM18QF",
         "session": "PRIVATE"

         }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'

    }
    response = requests.post(url, headers=headers, data=payload)
    assert response.status_code == 404



def test_get_tracking_coordinate_list():
    #url = data['trackingservice']["tracking_service_API5"] + data['userservice']['userID'] + "page=2" + "limit=10"
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/tracking-timeLine/918328189589?page=2&limit=10"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404

def test_get_tracking_coordinate_list2():
    #url = data['userservice']["tracking_service_API5"] + data['userservice']['userID'] + "page=2" + "limit=10"
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/tracking-timeLine/918328189589?page=2&limit=10"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404


def test_get_tracking_coordinate_list3():
    #url = data['trackingservice']["tracking_service_API5"] + data['userservice']['userID'] + "page=2" + "limit=10"
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/tracking-timeLine/918228189589?page=2&limit=10"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404


def test_update_tracking_event():
    #url = data['userservice']["tracking_service_API3"]
    url = data['userservice']["tracking_service_API8"]

    print(url)
    payload = json.dumps(
        {
            "trackingId": "65JE58QV",
            "sessionName": "wwwwww",
            "trackingType": "PRIVATE"
        }
    )


    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'user-token': data['userservice']['user-token'],
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
        #x-api-key is not there

    }
    response = requests.put(url, headers=headers, data=payload)
    #assert response.status_code == 404
    assert response.status_code == 200


# This test case is to Update tracking evnt with invalid Tracking ID
#def test_update_tracking_even2():
def test_update_tracking_even2_invalid_trackingId():

    #url = data['userservice']["tracking_service_API3"]
    url = data['userservice']["tracking_service_API8"]


    payload = json.dumps(
        {
            "trackingId": "86NM18QF",
            "sessionName": "9876",
            "trackingType": "public"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    # x-api-key is not there
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404


# This test case is to Update tracking event with empty payload
#def test_update_tracking_event3():
def test_update_tracking_event3_empty_payload():

    url = data['userservice']["tracking_service_API8"]


    payload = json.dumps(
       {
           "trackingId": "",
            "sessionName": "",
            "trackingType": ""
       }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    # x-api-key is not there

    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404

# This is a duplicate test case for the update_tracking_event()
# def test_update_tracking_event4():
#     url = data['userservice']["tracking_service_API8"]
#
#     payload = json.dumps(
#         {
#             "trackingId": "86NM18QF",
#             "sessionName": "pokjk",
#             "trackingType": "public"
#         }
#     )
#
#     headers = {
#         'accept': 'application/json',
#         'Content-Type': 'application/json'
#     }
#     response = requests.put(url, headers=headers, data=payload)
#     assert response.status_code == 404


def test_get_read_notification():
    #url = "https://tracking-service-backend-zid917893662962i53gvka-uc.a.run.app/api/trackingservice/get-readNotification/917893662962"

    #url="https://uat.bullittspace.com/api/trackingservice/get-readNotification/917893662962/"
    url=data['userservice']["tracking_service_API9"]
    print(url)
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'

    }
    #response = requests.get(url, headers=headers, data=payload)
    response = requests.get(url, headers=headers, data=payload)

    #assert response.status_code == 404
    assert response.status_code == 200


def test_read_notification():
    url = data['userservice']["tracking_service_API10"]

    payload = json.dumps(
        {
            "trackingId": "86NM18QF",
            "sessionName": "919876567999",
            "trackingType": "public"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url, headers=headers, data=payload)
    #assert response.status_code == 404
    assert response.status_code == 200



def test_delete_tracking_session():
    url = data['userservice']["tracking_service_API12_New"]

    payload = json.dumps(
        {
            "trackingId": "86NM18QF",
            "userId":"917893662962",
            "sessionName":"9876567999",
            "trackingType": "public"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'user-token': data['userservice']['user-token'],

        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'

    }
    response = requests.put(url, headers=headers, data=payload)
    # assert response.status_code == 404
    assert response.status_code == 200

#This testcase is to delete the tracking session with Empty User ID

#def test_delete_tracking_session2():
def test_delete_tracking_session2_with_empty_userId():

    url = data['userservice']["tracking_service_API12_New"]

    payload = json.dumps(
        {
            "trackingId": "86NM18QF",
            "userId":"",
            "sessionName":"9876567999",
            "trackingType": "public"
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'user-token': data['userservice']['user-token'],

        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'

    }
    response = requests.put(url, headers=headers, data=payload)
    #assert response.status_code == 404
    assert response.status_code == 400

# Try to delete the tracking session using a tracking Id which is already deleted
def test_delete_tracking_session3():
    url = data['userservice']["tracking_service_API12_New"]

    payload = json.dumps(
        {
            "userId": "917893662962",
                "trackingIds": [
                                    "77YE39RE"
                                ]

    }
         )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url, headers=headers, data=payload)
    assert response.status_code == 404


#This testcase is to delete the tracking session with empty playload
#def test_delete_tracking_session4():
def test_delete_tracking_session4_with_empty_payload():

    url = data['userservice']["tracking_service_API12_New"]

    payload = json.dumps(
        {
            "trackingId": "",
            "sessionName": "",
            "trackingType": ""
        }
    )

    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk',

        'user-token': data['userservice']['user-token']

    }
    response = requests.put(url, headers=headers, data=payload)
    # assert response.status_code == 404
    assert response.status_code == 400


def test_get_tracking_coordinate_list_withusertoken():
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/get-readNotification/999999999"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_get_tracking_coordinate_list_withusertoken2():
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/get-readNotification/999999999"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_get_tracking_coordinate_list_withusertoken3():
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/get-readNotification/8321889589"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404
def test_get_tracking_coordinate_list_withusertoken4():
    url = "https://tracking-service-backend-zidi53gvka-uc.a.run.app/api/trackingservice/get"
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token']
        # 'Content-Type': 'application/json'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 404
