import os
import requests
import json
import pytest
from _pytest import fixtures

from conftest import auth_key

#from API_Automation.conftest import *
path=os.getcwd()
print(path)
os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)
    # input_file.close()



def test_add_or_update_tracking_value():
    #url=data['userservice']["tracking_service_API1"]
    url = data['userservice']['tracking_service_API1']
    payload = json.dumps(
        {

  "sender": "917893662962",
  "messageType": "STARTTRACKING",
  "latitude": "30",
  "longitude": "40",
  "messageId": "55279c08-58d7-46eb-b74c-5535c3cb3f5c"

}
    )


    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url, headers=headers, data=payload)
    print(response)
    assert response.status_code == 404

def test_gettracking_contact_list():
    #url=data['userservice']['tracking_service_API2']+"/user/"+data['userservice']['userID']
    #url = data['userservice']["tracking_service_API2"] + "/user/" + data['userservice']['userID']
    #url = data['userservice']['tracking_service_API2'] + "/" + data['userservice']['userID']

    #url = data['userservice']['tracking_service_API2']
    url="https://uat.bullittspace.com/api/trackingservice/tracking-contactList/917893662962"
    print(url)
    payload = ""

    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.get(url, headers=headers, data=payload)
    assert response.status_code == 200


def test_Delete_tracking_contact_list():
    url=data['userservice']["tracking_service_API3"]
    payload = json.dumps(
        {
            "mobileNumber": "917893662962",
            "trackingData": [
                {
                    "name": "Srinu Org",
                    "value":"91818686101312"

                }
            ]
        }
    )
    headers = {
        'accept': 'application/json',
        'user-token': data['userservice']['user-token'],
        'Content-Type': 'application/json',
        'x-api-key': 'AIzaSyChEKE71C4e4kC2fd30e4Jy7aLE3ewWNlk'
    }
    response = requests.put(url,headers=headers,data=payload)
    assert response.status_code == 404