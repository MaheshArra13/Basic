import os

import requests
import json
import pytest
from _pytest import fixtures

from conftest import auth_key

path=os.getcwd()
print(path)
# create or update user details

os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open("config.json") as input_file:
    data = json.load(input_file)
    # input_file.close()

# Create or update BSS services enabled/disabled using valid IMSI details
def test_fetch_bss_services():
    url = data['bss_service']['bss_service_API1']

    #url = ""
    payload = json.dumps({

            "imsiList": ["901800010000071"]

    })
    #key="'{}'" .format(auth_key)
    #print(key)
    headers = {
        'accept': 'application/json',
        #'user-token': data['bss_service']['user-token'],
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 200

# Create or update BSS services enabled/disabled using Invalid IMSI details
def test_fetch_bss_services():
    url = data['bss_service']['bss_service_API1']

    #url = ""
    payload = json.dumps({

            "imsiList": ["901800011"]

    })
    #key="'{}'" .format(auth_key)
    #print(key)
    headers = {
        'accept': 'application/json',
        #'user-token': data['bss_service']['user-token'],
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 200

# Create or update BSS services enabled/disabled using empty IMSI
def test_fetch_bss_services():
    url = data['bss_service']['bss_service_API1']

    #url = ""
    payload = json.dumps({

            "imsiList": [""]

    })
    #key="'{}'" .format(auth_key)
    #print(key)
    headers = {
        'accept': 'application/json',
        #'user-token': data['bss_service']['user-token'],
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 200

# Create or update user details with empty IMSI details

# Bss quota update using IMSI
def test_quota_update_using_imsi():
    url = data['bss_service']['bss_service_API2']

    #url = ""
    payload = json.dumps({

        "currentQuota": {
		"messagingQuota": 1000000,
		"trackingQuota": 1000000,
		"sosService": "PREMIUM",
		"curExpiryDateTimeMs": 1662535630
	},
	"newQuota": {
		"messagingQuota": 100,
		"trackingQuota": 100,
		"sosService": "STANDARD",
		"newExpiryDateTimeMs": 1662535630
	}


    })
    #key="'{}'" .format(auth_key)
    #print(key)
    headers = {
        'accept': 'application/json',
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 200

# Validate data for user usagecheck
def test_bss_data_user_usagecheck():

    url = data['bss_service']['bss_service_API3']

    payload = json.dumps({

            "messagingService": True,
            "trackingService": True,
            "sosService": True
    })

    headers = {
        'accept': 'application/json',
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 200

# Validate data for user usagecheck with invalid payload
def test_bss_data_user_usagecheck():

    url = data['bss_service']['bss_service_API3']

    payload = json.dumps({

            "messagingService": "",
            "trackingService": " ",
            "sosService": " "
    })

    headers = {
        'accept': 'application/json',
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 400

# Validate data for user usagecheck with invalid IMSI
def test_bss_data_user_usagecheck():

    url = data['bss_service']['bss_service_API2_invalid_IMSI']

    payload = json.dumps({

           "messagingService": True,
            "trackingService": True,
            "sosService": True
    })

    headers = {
        'accept': 'application/json',
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 400


# Validate data for user usagecheck with all services empty
def test_bss_data_user_usagecheck():

    url = data['bss_service']['bss_service_API2_invalid_IMSI']

    payload = json.dumps({

           "messagingService": "",
            "trackingService": "",
            "sosService": ""
    })

    headers = {
        'accept': 'application/json',
        'APP-ID':'bullitt-aws.msg.uat',
        'Content-Type': 'application/json',
        'x-api-key': 'ESTBV0xWBZ7txnfRcBdVc71ymkAXDKlI5Mg2vXj0'
    }
    response = requests.post(url, headers=headers, data=payload)
    print(response.text)
    assert response.status_code == 400




