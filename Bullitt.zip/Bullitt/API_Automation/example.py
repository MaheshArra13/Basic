import json
with open("config.json") as f:
    data=json.load(f)
print(data['messageId'])
number= num
# print(number)

