import logging
import os
import smtplib
import ssl
import sys
import time
from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
import openpyxl
from openpyxl.styles import PatternFill
from openpyxl.chart import PieChart, Reference
from openpyxl.chart.label import DataLabelList


log = logging.getLogger("MailReport")
stdout_handler = logging.StreamHandler(sys.stdout)
log.addHandler(stdout_handler)

smtp_server = "smtp-mail.outlook.com"
port = 587
sender = 'apolagoni@innominds.com'
key = "8328189589@VR"
recipients = ["apolagoni@innominds.com","tkamma@innominds.com"]
script_path = os.getcwd()


# print(script_path)

# below function will post process the data obtained after executing all the test cases and create a pie chart
# summary report for all the test cases execute
def prepare_message_to_send_mail(attachment_path):
    test_type_summary_list = []
    Testcase = []
    wb_obj = openpyxl.load_workbook(attachment_path)
    sheet_obj = wb_obj.active
    cell_obj = sheet_obj.cell(row=1, column=4)
    wb_obj.create_sheet("Summary")
    New_worksheet = wb_obj["Summary"]
    # print(cell_obj.value)
    # print(sheet_obj.max_row)
    col_range = sheet_obj.max_column
    for col in range(1, col_range + 1):
        cell_header = sheet_obj.cell(1, col)
        cell_header.fill = PatternFill(patternType='solid', fgColor='E37C66')

    Passed = 0
    Failed = 0
    Skipped = 0
    for i in range(1, sheet_obj.max_row + 1):
        cell_obj = sheet_obj.cell(row=i, column=4)
        print(cell_obj.value)
        if cell_obj.value == "PASSED":
            pass_cell = sheet_obj.cell(i, 4)
            pass_cell.fill = PatternFill(patternType='solid', fgColor='00D100')
            Passed += 1
        elif cell_obj.value == "FAILED":
            fail_cell = sheet_obj.cell(i, 4)
            fail_cell.fill = PatternFill(patternType='solid', fgColor='FF3838')
            Failed += 1
        elif cell_obj.value == "SKIPPED":
            Skipped += 1
            skip_cell = sheet_obj.cell(i, 4)
            skip_cell.fill = PatternFill(patternType='solid', fgColor='FFFF5C')
        else:
            pass

    total_cases = Passed + Failed + Skipped

    datas = [
        ['Status', 'Count'],
        ['Passed', Passed],
        ['Failed', Failed],
        ['Skipped', Skipped],
        ['Total', total_cases],
    ]
    for row in datas:
        New_worksheet.append(row)

    chart = PieChart()

    labels = Reference(New_worksheet, min_col=1,
                       min_row=2, max_row=4)

    data = Reference(New_worksheet, min_col=2,
                     min_row=1, max_row=4)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(labels)
    chart.title = "API-Automation Summary Report"
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showPercent = True
    New_worksheet.add_chart(chart, "E2")
    # print("Passed:", Passed)
    # print("Failed:", Failed)
    # print("Skipped:", Skipped)
    wb_obj.save(attachment_path)
    test_type_summary = f"""
    <p style="font-family:arial; color:#000000; font-size:14px; line-height:0.5;"><b>Total Cases : </b>{total_cases}</p>
    <p style="font-family:arial; color:#008000; font-size:14px; line-height:0.5;"><b>Passed : </b>{Passed}</p>
    <p style="font-family:arial; color:#FF0000; font-size:14px; line-height:0.5;"><b>Failed : </b>{Failed}</p>
    <p style="font-family:arial; color:#8B8000; font-size:14px; line-height:0.5;"><b>Not Executed : </b>{Skipped}</p>
    <br style="line-height:0.2;">"""
    test_type_summary_list.append(test_type_summary)
    all_test_types_summary = "".join(test_type_summary_list)
    message = """Hi All, 
                 Please find the Attached API Automation Test report\n""" + all_test_types_summary
    return message


def send_mail(mail_subject, message, attachment):
    try:
        log.info("***** Sending test report through mail *****")
        log.info("***** preparing mail body to send through mail *****")
        msg = MIMEMultipart()
        msg['Subject'] = mail_subject
        msg['From'] = sender
        msg['To'] = ", ".join(recipients)
        msg.attach(MIMEText(message, 'html'))
        p = MIMEBase('application', 'octet-stream')
        p.set_payload(open(attachment, "rb").read())
        encoders.encode_base64(p)
        p.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(attachment))
        msg.attach(p)
        log.info("***** Establishing connection with mail server *****")
        server = smtplib.SMTP(f'{smtp_server}:{port}')
        server.ehlo()
        server.starttls()
        server.login(sender, key)
        log.info("***** Establised connection with mail server *****")
        server.ehlo()
        server.sendmail(sender, recipients, str(msg))
        log.info(f"***** Mail sent successfully *****")
        server.quit()
    except Exception as e:
        log.error(f"Unable to send test report through mail : {str(e)}")


##################### Debug Code #####################
if __name__ == "__main__":
    start_time = datetime.now()
    time.sleep(2)
    end_time = datetime.now()
    # message = prepare_message_to_send_mail()
    # attachment_path = r'C:\Users\smart\PycharmProjects\ATF\TestFramework\dev\plug.png'
    attachment_path = r"//API_Automation/User_service/report.xlsx"
    message = prepare_message_to_send_mail(attachment_path)
    report_header_date = datetime.now()
    mail_subject = f"Skylo API Test Report, dated {report_header_date}"
    send_mail(mail_subject, message, attachment_path)
