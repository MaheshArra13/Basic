import os
# import pytest
import json
import re

import pytest
import requests

# import requests
# import re
#
# # uncomment below line while running individual test script and comment other os.chidr("lib/") below
# #print("#######")
#print("####", os.getcwd())
#os.chdir("../lib/")
#print(os.getcwd())
# Opening config.json file reading the json file and assigning it to a data
#
path=os.getcwd()
print(path)
# os.chdir('C:\\Users\\apolagoni\\Downloads\\skylo API\\lib')
os.chdir('D:\\Bullitt\\API_Automation\\lib')
with open('config.json') as input_file:
    #global data
    data = json.load(input_file)
    #print(type(data["messageId"]))

    #num=data["messageId"]



@pytest.fixture
def auth_key():
    url='https://arwkayloeozsuwedzilb.supabase.co/auth/v1/token?grant_type=password'
    payload = json.dumps({

            "phone": "+919515483896",
            "password": "Tharun@1234"
        })
    headers = {
             #'Authorization': "Bearer",
            'Content-Type': 'application/json',
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFyd2theWxvZW96c3V3ZWR6aWxiIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njg0MTAyMzcsImV4cCI6MTk4Mzk4NjIzN30.9IVUxDr4gaTS6wuWy44fCdwbNpttlv2ThPnhqhwHGhc',
            'Cookie': 'sb-access-token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNjcyNjM3OTU3LCJzdWIiOiI2YmY5ODcwYS00ODU5LTQxOTYtYjEwNS1lZWQ5M2E0NDI4MzQiLCJlbWFpbCI6IiIsInBob25lIjoiOTE5OTg1MjEyMDE3IiwiYXBwX21ldGFkYXRhIjp7InByb3ZpZGVyIjoicGhvbmUiLCJwcm92aWRlcnMiOlsicGhvbmUiXX0sInVzZXJfbWV0YWRhdGEiOnt9LCJyb2xlIjoiYXV0aGVudGljYXRlZCIsImFhbCI6ImFhbDEiLCJhbXIiOlt7Im1ldGhvZCI6InBhc3N3b3JkIiwidGltZXN0YW1wIjoxNjcyMDMzMTU3fV0sInNlc3Npb25faWQiOiI1ODlhNmM0Ni1kZWMxLTQxYzQtYTlkNC05YWMwZDgxNDViNjgifQ.hbYb82NNljSxZ9XhtoGeZAjjhIN-d14CppiXJkN_VBE; sb-refresh-token=TJJ9K9UEaWzW5rotW_a6bQ'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    response_string = response.text
    print(response.text)
    #response_data=response.text
    res = json.loads(response_string)
    #admin_key = re.search('\"refresh_token\":\"(.*?)\"', response_string)
    #print(admin_key.group(1))
    auththorization_key = res['refresh_token']
    print(auththorization_key)
    return auththorization_key




    #print(num)
    #print(data["messageId"])

# # creating a url from the parameters from config.json file
# url = data['QA_Authenticate_tenant']
#
#
# # Generating and returning the   auth key
# @pytest.fixture
# def auth_key():
#     payload = json.dumps({
#         "userName": data["username"],
#         "password": data["password"]
#     })
#     headers = {
#         'Authorization': "Bearer",
#         'Content-Type': 'application/json'
#     }
#
#     response = requests.request("POST", url, headers=headers, data=payload)
#     print(dir(response))
#     print(response.status_code)
#     print(response.text)
#     response_string = response.text
#     auth_key = re.search('\"access_token\":\"(.*?)\"', response_string)
#     print(auth_key.group(1))
#     Auth_key = auth_key.group(1)
#     return Auth_key


# @pytest.fixture
# def admin_key():
#     url = data['QA_ADMIN_AUTHENTICATION']
#     payload = json.dumps({
#         "userName": data["username"],
#         "password": data["password"]
#     })
#     headers = {
#         'Authorization': "bearer",
#         'Content-Type': 'application/json'
#     }
#
#     response = requests.request("POST", url, headers=headers, data=payload)
#     print(dir(response))
#     print(response.status_code)
#     print(response.text)
#     response_string = response.text
#     admin_key = re.search('\"access_token\":\"(.*?)\"', response_string)
#     print(admin_key.group(1))
#     Admin_key = admin_key.group(1)
#     return Admin_key
# # auth_key()
