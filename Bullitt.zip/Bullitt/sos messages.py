from distutils.command.config import config

import pytest
import re
import requests
import json
import os
import json



#import
# from conftest import *
# from lib.config import *
with open("config.json") as input_file:
    data = json.load(input_file)
    input_file.close()




def testreceive_SOS_message_event_from_FP4():
    #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    #url = data['sosservices']['sosAPI4']
    url = data['sosservices']['sosAPIDEV4']
    payload4 = json.dumps({
        "customerId": data['sosservices']['customerId7'],
        "content": "inno1"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 200

def testreceive_SOS_message_event_from_FP4_1():
    #url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    #url = data['sosservices']['sosAPI4']
    url = data['sosservices']['sosAPIDEV4']
    payload4 = json.dumps({
        "customerId": data['sosservices']['customerId7'],
        "content": "inno2"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 200

def testreceive_SOS_message_event_from_FP4_2():
        # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
        # url = data['sosservices']['sosAPI4']
        url = data['sosservices']['sosAPIDEV4']
        payload4 = json.dumps({
            "customerId": data['sosservices']['customerId7'],
            "content": "inno2"
        })
        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.post(url, headers=headers, data=payload4)
        assert response.status_code == 200


def testreceive_SOS_message_event_from_FP4_3():
    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    # url = data['sosservices']['sosAPI4']
    url = data['sosservices']['sosAPIDEV4']
    payload4 = json.dumps({
        "customerId": data['sosservices']['customerId7'],
        "content": "inno3"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 200

def testreceive_SOS_message_event_from_FP4_4():
        # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
        # url = data['sosservices']['sosAPI4']
        url = data['sosservices']['sosAPIDEV4']
        payload4 = json.dumps({
            "customerId": data['sosservices']['customerId7'],
            "content": "inno4"
        })
        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.post(url, headers=headers, data=payload4)
        assert response.status_code == 200


def testreceive_SOS_message_event_from_FP4_5():
    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    # url = data['sosservices']['sosAPI4']
    url = data['sosservices']['sosAPIDEV4']
    payload4 = json.dumps({
        "customerId": data['sosservices']['customerId7'],
        "content": "inno5"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 200

def testreceive_SOS_message_event_from_FP4_6():
        # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
        # url = data['sosservices']['sosAPI4']
        url = data['sosservices']['sosAPIDEV4']
        payload4 = json.dumps({
            "customerId": data['sosservices']['customerId7'],
            "content": "inno6"
        })
        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.post(url, headers=headers, data=payload4)
        assert response.status_code == 200


def testreceive_SOS_message_event_from_FP4_7():
    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    # url = data['sosservices']['sosAPI4']
    url = data['sosservices']['sosAPIDEV4']
    payload4 = json.dumps({
        "customerId": data['sosservices']['customerId7'],
        "content": "inno7"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 200

def testreceive_SOS_message_event_from_FP4_8():
        # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
        # url = data['sosservices']['sosAPI4']
        url = data['sosservices']['sosAPIDEV4']
        payload4 = json.dumps({
            "customerId": data['sosservices']['customerId7'],
            "content": "inno8"
        })
        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/json'
        }
        response = requests.post(url, headers=headers, data=payload4)
        assert response.status_code == 200


def testreceive_SOS_message_event_from_FP4_9():
    # url = "https://cloud-sos-microservice-246pqtymlq-uc.a.run.app/delivery-status"
    # url = data['sosservices']['sosAPI4']
    url = data['sosservices']['sosAPIDEV4']
    payload4 = json.dumps({
        "customerId": data['sosservices']['customerId7'],
        "content": "inno9"
    })
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json'
    }
    response = requests.post(url, headers=headers, data=payload4)
    assert response.status_code == 200




